function validate() {
    // Reset error messages
    document.getElementById('usernameError').style.display = 'none';
    document.getElementById('emailError').style.display = 'none';
    document.getElementById('passwordError').style.display = 'none';
    document.getElementById('confirmPasswordError').style.display = 'none';
    document.getElementById('addressError').style.display = 'none';
    document.getElementById('genderError').style.display = 'none';
    document.getElementById('tncError').style.display = 'none';

    // Get form values
    var username = document.getElementById('username').value;
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;
    var confirmPassword = document.getElementById('confirmPassword').value;
    var address = document.getElementById('address').value;
    var gender = document.querySelector('input[name="genderButton"]:checked');
    var tnc = document.getElementById('tnc').checked;

    // Validate username
    if (username === "") {
        document.getElementById('usernameError').style.display = 'block';
        return false;
    }

    // Validate email
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        document.getElementById('emailError').style.display = 'block';
        return false;
    }

    // Validate password
    if (password === "") {
        document.getElementById('passwordError').style.display = 'block';
        return false;
    }

    // Validate confirmPassword
    if (confirmPassword !== password) {
        document.getElementById('confirmPasswordError').style.display = 'block';
        return false;
    }

    // Validate address
    if (address === "") {
        document.getElementById('addressError').style.display = 'block';
        return false;
    }

    // Validate gender
    if (!gender) {
        document.getElementById('genderError').style.display = 'block';
        return false;
    }

    // Validate terms and conditions
    if (!tnc) {
        document.getElementById('tncError').style.display = 'block';
        return false;
    }

    // If everything is valid, the form will be submitted
    alert("Form submitted successfully!");
    return true;
}
