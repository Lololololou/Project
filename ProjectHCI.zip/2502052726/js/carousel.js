let currentIndex = 0;
const totalItems = document.querySelectorAll('.bannerItem').length;

function showImage(index) {
    const items = document.querySelectorAll('.bannerItem');
    if (index < 0) {
        currentIndex = totalItems - 1;
    } else if (index >= totalItems) {
        currentIndex = 0;
    } else {
        currentIndex = index;
    }

    items.forEach((item, i) => {
        if (i === currentIndex) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}

function next() {
    showImage(currentIndex + 1);
}

function prev() {
    showImage(currentIndex - 1);
}

// Show the initial image when the page loads
document.addEventListener('DOMContentLoaded', function () {
    showImage(currentIndex);
});
